<?php
$wp = $_GET['wp'];

$url = 'http://opencaching.pl/search.php?searchto=searchbywaypoint&showresult=1&f_inactive=0&f_ignored=0&f_userfound=0&f_userowner=0&f_watched=0&startat=0&waypoint=' ;
$url .= $wp ;
$url .= '&output=gpxgc' ;	
$xml = file_get_contents($url);
header("Content-Type: text/xml");
echo $xml;
				
// Open the Curl session
//$session = curl_init($url);

// Return the call not the headers
//curl_setopt($session, CURLOPT_HEADER, false);
//curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

// call the data
//$xml = curl_exec($session);
//header("Content-Type: text/xml");
//echo $xml;
//curl_close($session);
?>